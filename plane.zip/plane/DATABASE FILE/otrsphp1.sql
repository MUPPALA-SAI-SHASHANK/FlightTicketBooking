-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2023 at 05:10 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `otrsphp1`
--

-- --------------------------------------------------------

--
-- Table structure for table `booked`
--

CREATE TABLE `booked` (
  `id` int(11) NOT NULL,
  `schedule_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code` varchar(100) NOT NULL,
  `class` varchar(10) NOT NULL DEFAULT 'second',
  `no` int(11) NOT NULL DEFAULT 1,
  `seat` varchar(30) NOT NULL,
  `date` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booked`
--

INSERT INTO `booked` (`id`, `schedule_id`, `payment_id`, `user_id`, `code`, `class`, `no`, `seat`, `date`) VALUES
(39, 115, 51, 11, '2023/0115/1577', 'second', 5, 'S01 - S05', 'Thu, 22-Jun-2023 03:44:19 PM'),
(40, 113, 52, 12, '2023/0113/162', 'first', 2, 'F01 - F02', 'Thu, 22-Jun-2023 03:47:34 PM'),
(41, 114, 53, 13, '2023/0114/1521', 'first', 10, 'F01 - F10', 'Thu, 22-Jun-2023 03:51:33 PM'),
(42, 118, 54, 14, '2023/0118/1120', 'second', 1, 'S001', 'Thu, 22-Jun-2023 03:54:21 PM'),
(43, 115, 55, 15, '2023/0115/6616', 'second', 3, 'S06 - S08', 'Thu, 22-Jun-2023 03:58:03 PM');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(400) NOT NULL,
  `response` varchar(400) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `message`, `response`) VALUES
(14, 11, 'Easy to Book Tickets and the service tooo good\r\n', NULL),
(15, 12, 'Besssssssssst Service ', NULL),
(16, 13, 'Just loved it', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(40) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `loc` varchar(40) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`id`, `name`, `email`, `password`, `phone`, `address`, `loc`, `status`) VALUES
(11, 'ABC-UserName', 'abc@gmail.com', 'b24331b1a138cde62aa1f679164fc62f', '01234567890', '2nd Floor, Bandra West, Mumbai', '4c08734c16dc55ab092be751b135b63a.jpeg', 1),
(12, '1234567890', '123@gmail.com', '53e6086284353cb73d4979f08537d950', '09876543210', '18 block, new nagar, kerala', '9ce02f5102094037c58ceeb8d7fc5b3f.jpeg', 1),
(13, 'xyz-username', 'xyz@gmail.com', '742f40cbb203f3b2c879a72a2828dac1', '01234543210', '3rd cross, India nagar, Delhi', '7dceb5ef3d74412ca5da82ef077dbe31.jpeg', 1),
(14, 'mno-username', 'mno@gmail.com', '892afebfe010f508341ab474261e5856', '09182736450', '3rd Street, Nagar Road, Patna', 'ac4c2270852be657562654ad874c18e6.jpeg', 1),
(15, '987-username', '987@gmail.com', 'a2a52f1c31d127c0c847eca113daf7c6', '01928374650', '212-A, Sagar Nagar', '79ccff7f5e1e3b5fc441af10557e0872.jpeg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `passenger_id` int(11) NOT NULL,
  `schedule_id` int(11) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `ref` varchar(100) NOT NULL,
  `date` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `passenger_id`, `schedule_id`, `amount`, `ref`, `date`) VALUES
(51, 11, 115, '1010', '08S1DF01I6', 'Thu, 22-Jun-2023 03:44:19 PM'),
(52, 12, 113, '1212', '5HAJBAEVJ1', 'Thu, 22-Jun-2023 03:47:34 PM'),
(53, 13, 114, '2020', 'EN9NO390OT', 'Thu, 22-Jun-2023 03:51:33 PM'),
(54, 14, 118, '202', 'J3HMJKDJ08', 'Thu, 22-Jun-2023 03:54:21 PM'),
(55, 15, 115, '606', '1RTJ3ZBBJ7', 'Thu, 22-Jun-2023 03:58:03 PM');

-- --------------------------------------------------------

--
-- Table structure for table `plane`
--

CREATE TABLE `plane` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `first_seat` int(11) NOT NULL,
  `second_seat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plane`
--

INSERT INTO `plane` (`id`, `name`, `first_seat`, `second_seat`) VALUES
(16, 'SkyScreamer HyperX', 200, 250),
(17, 'JetVelocity Express', 100, 150),
(18, 'AeroZoom Rapid', 150, 200),
(19, 'FlyShine Express', 200, 250),
(20, 'SkySonic Sprinter', 300, 400),
(21, 'TurboJet Velocity', 70, 90),
(22, 'Flymania Express', 50, 75),
(23, 'AeroGlide Speedster', 75, 75),
(24, 'AeroRush Express', 60, 80),
(25, 'FlyRush Thunderbolt', 75, 100),
(26, 'AirFlash Lightning', 100, 125);

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `id` int(11) NOT NULL,
  `start` varchar(100) NOT NULL,
  `stop` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`id`, `start`, `stop`) VALUES
(3, 'New Delhi', 'Mumbai'),
(4, 'Chennai', 'Kolkata'),
(5, 'Tirupati', 'Shirdi'),
(6, 'Bangalore', 'Lucknow'),
(7, 'Agra', 'Mysore'),
(8, 'Patna', 'Pondicherry'),
(9, 'Madurai', 'Nasik'),
(10, 'Rajahmundry', 'Nasik'),
(11, 'Visakhapatnam', 'Varanasi'),
(12, 'Hyderabad', 'Vijayawada'),
(13, 'Bhubaneshwar', 'Simla'),
(14, 'Jammu', 'Aurangabad'),
(15, 'Aizwal', 'Trivandrum'),
(16, 'Allahabad', 'Jaisalmer'),
(17, 'Surat', 'Port Blair'),
(18, 'Gwalior', 'Tirupati'),
(19, 'Mysore', 'Varanasi');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `plane_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` varchar(10) NOT NULL,
  `first_fee` float NOT NULL,
  `second_fee` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `plane_id`, `route_id`, `date`, `time`, `first_fee`, `second_fee`) VALUES
(112, 16, 3, '01-07-2023', '05:30', 200, 125),
(113, 23, 10, '01-07-2023', '06:00', 600, 450),
(114, 24, 5, '08-07-2023', '02:00', 200, 150),
(115, 21, 14, '15-07-2023', '20:00', 250, 200),
(116, 19, 6, '10-07-2023', '18:00', 125, 75),
(117, 17, 18, '29-06-2023', '14:30', 300, 225),
(118, 18, 7, '25-06-2023', '22:30', 250, 200);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`) VALUES
(1, 'admin@admin.com', 'D00F5D5217896FB7FD601412CB890830');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booked`
--
ALTER TABLE `booked`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `schedule_id` (`schedule_id`,`user_id`,`payment_id`) USING BTREE,
  ADD KEY `schedule_id_2` (`schedule_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `passenger_id` (`passenger_id`,`schedule_id`),
  ADD KEY `passenger_id_2` (`passenger_id`) USING BTREE,
  ADD KEY `schedule_id` (`schedule_id`);

--
-- Indexes for table `plane`
--
ALTER TABLE `plane`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plane_id` (`plane_id`),
  ADD KEY `route_id` (`route_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booked`
--
ALTER TABLE `booked`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `passenger`
--
ALTER TABLE `passenger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `plane`
--
ALTER TABLE `plane`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `route`
--
ALTER TABLE `route`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booked`
--
ALTER TABLE `booked`
  ADD CONSTRAINT `booked_ibfk_1` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`id`),
  ADD CONSTRAINT `booked_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `passenger` (`id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`id`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`id`);

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`plane_id`) REFERENCES `plane` (`id`),
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
