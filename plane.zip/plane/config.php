<?php
$title = 'Online Ticket Reservation System';
//E-Ticketing System For Railway
$supervisor_name = "MUPPALA SAI SHASHANK";
$developer_name = "MUPPALA SAI SHASHANK";
$developer_matric = "20BF1A3332";
